# PRTI-GH anonymization report

## Method and configuration

Wei/MO-OBAM was used without adding suppression, masking, differential privacy, or another anonymization transformation.

```json
{
  "run_label": "dense-selected-c004-k16-heldout-seed12",
  "model": {
    "k": 16,
    "n_clusters": 4,
    "lambda_weight": 2e-07
  },
  "pso": {
    "population_size": 100,
    "iterations": 100,
    "seed": 12,
    "random_coefficient_max": 0.01
  }
}
```

## Headline results

| Metric | Before | After |
|---|---:|---:|
| Equivalence classes | 1481 | 4 |
| Achieved k | 1 | 278 |
| Maximum prosecutor risk | 1.00000000 | 0.00359712 |
| Mean prosecutor risk | 0.99730640 | 0.00269360 |
| Marketer risk | 0.99730640 | 0.00269360 |
| Information loss | not applicable | 0.4602407399 |

The prosecutor and marketer values are sample-based equivalence-class risks. Journalist risk is not estimated because population QID frequencies and the sampling fraction are unavailable.

## Diversity

- Minimum distinct l-diversity across all released classes and sensitive attributes: **2**.
- Minimum entropy-effective diversity, `exp(H)`: **1.024120**.
- This is measured evidence, not an added l-diversity constraint in Wei's optimizer.

## Distribution similarity

- QIDs with changed records: **29** of 29.
- Sensitive attributes with changed records: **0** of 77.
- Numeric attributes use normalized Wasserstein distance and the KS statistic.
- Categorical attributes use total variation and Jensen-Shannon distance.

## Release boundary

These measurements support technical review but do not replace custodian, governance, clinical, or independent disclosure-control approval.
